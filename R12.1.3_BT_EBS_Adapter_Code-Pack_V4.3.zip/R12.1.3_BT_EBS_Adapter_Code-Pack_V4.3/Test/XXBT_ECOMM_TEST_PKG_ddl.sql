-- This is for INTERNAL TESTING ONLY.
-- Not needed for regular Run / Testing etc.
-- Do not USE.

-- Package Spec.
CREATE OR REPLACE PACKAGE xxbt_ecomm_test_pkg
AS

PROCEDURE process_order(p_party_name IN VARCHAR2
                       ,p_item_name IN VARCHAR2 DEFAULT '0001-0120H'
                       ,p_item_qty IN NUMBER DEFAULT 2
                       ,p_pamt_method_type IN VARCHAR2
                       ,p_cc_num IN VARCHAR2
                       ,p_cc_expiration_date IN VARCHAR2 --MM/YYYY
                       ,p_cc_code IN VARCHAR2
                       ,p_card_holder_name IN VARCHAR2
                       ,p_po_number IN VARCHAR2
                       ,p_pmt_method_opn_type IN VARCHAR2 DEFAULT 'I'
                       ,p_bt_auth_code IN VARCHAR2
                       ,p_bt_transaction_id IN VARCHAR2
                       ,p_bt_customer_id IN VARCHAR2
                       ,p_bt_payment_method_token IN VARCHAR2
                       ,x_ret_status OUT VARCHAR2
                       ,x_ret_message OUT VARCHAR2
                       ,x_order_num OUT VARCHAR2
                       ,x_instrid OUT NUMBER
                       ,x_ret_cc_det_id OUT NUMBER
                       ,x_ret_pymt_tran_id OUT NUMBER
                       );
END xxbt_ecomm_test_pkg;
/


-- Package Spec.
CREATE OR REPLACE PACKAGE BODY xxbt_ecomm_test_pkg
AS
PROCEDURE process_order(p_party_name IN VARCHAR2
                       ,p_item_name IN VARCHAR2 DEFAULT '0001-0120H'
                       ,p_item_qty IN NUMBER DEFAULT 2
                       ,p_pamt_method_type IN VARCHAR2
                       ,p_cc_num IN VARCHAR2
                       ,p_cc_expiration_date IN VARCHAR2 --MM/YYYY
                       ,p_cc_code IN VARCHAR2
                       ,p_card_holder_name IN VARCHAR2
                       ,p_po_number IN VARCHAR2
                       ,p_pmt_method_opn_type IN VARCHAR2 DEFAULT 'I'
                       ,p_bt_auth_code IN VARCHAR2
                       ,p_bt_transaction_id IN VARCHAR2
                       ,p_bt_customer_id IN VARCHAR2
                       ,p_bt_payment_method_token IN VARCHAR2
                       ,x_ret_status OUT VARCHAR2
                       ,x_ret_message OUT VARCHAR2
                       ,x_order_num OUT VARCHAR2
                       ,x_instrid OUT NUMBER
                       ,x_ret_cc_det_id OUT NUMBER
                       ,x_ret_pymt_tran_id OUT NUMBER
                       )
IS

   lc_po_num  VARCHAR2(50) := p_po_number||xxbt_bt_payment_trxns_s.nextval;
   l_header_rec                    OE_ORDER_PUB.Header_Rec_Type;
   x_header_rec                    OE_ORDER_PUB.Header_Rec_Type;
   l_line_tbl                      OE_ORDER_PUB.Line_Tbl_Type;
   l_action_request_tbl            OE_ORDER_PUB.Request_Tbl_Type :=  OE_ORDER_PUB.G_MISS_REQUEST_TBL;
   l_header_adj_tbl                OE_ORDER_PUB.Header_Adj_Tbl_Type;
   l_line_adj_tbl                  OE_ORDER_PUB.line_adj_tbl_Type;
   l_header_scr_tbl                OE_ORDER_PUB.Header_Scredit_Tbl_Type;
   l_line_scredit_tbl              OE_ORDER_PUB.Line_Scredit_Tbl_Type;
   l_request_rec                   OE_ORDER_PUB.Request_Rec_Type;
   l_return_status                 VARCHAR2 (1000);
   l_msg_count                     NUMBER;
   l_msg_data                      VARCHAR2 (1000);
   p_api_version_number            NUMBER := 1.0;
   p_init_msg_list                 VARCHAR2 (10) := FND_API.G_FALSE;
   p_return_values                 VARCHAR2 (10) := FND_API.G_FALSE;
   p_action_commit                 VARCHAR2 (10) := FND_API.G_FALSE;
   x_return_status                 VARCHAR2 (1);
   x_msg_count                     NUMBER;
   x_msg_data                      VARCHAR2 (100);
   p_header_rec                    OE_ORDER_PUB.Header_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_REC;

   p_old_header_rec                OE_ORDER_PUB.Header_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_REC;
   p_header_val_rec                OE_ORDER_PUB.Header_Val_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_VAL_REC;
   p_old_header_val_rec            OE_ORDER_PUB.Header_Val_Rec_Type := OE_ORDER_PUB.G_MISS_HEADER_VAL_REC;
   p_Header_Adj_tbl                OE_ORDER_PUB.Header_Adj_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL;
   p_old_Header_Adj_tbl            OE_ORDER_PUB.Header_Adj_Tbl_Type := OE_ORDER_PUB.G_MISS_HEADER_ADJ_TBL;
   p_Header_Adj_val_tbl            OE_ORDER_PUB.Header_Adj_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_ADJ_VAL_TBL;
   p_old_Header_Adj_val_tbl        OE_ORDER_PUB.Header_Adj_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_ADJ_VAL_TBL;
   p_Header_price_Att_tbl          OE_ORDER_PUB.Header_Price_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_PRICE_ATT_TBL;
   p_old_Header_Price_Att_tbl      OE_ORDER_PUB.Header_Price_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_PRICE_ATT_TBL;
   p_Header_Adj_Att_tbl            OE_ORDER_PUB.Header_Adj_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ATT_TBL;
   p_old_Header_Adj_Att_tbl        OE_ORDER_PUB.Header_Adj_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ATT_TBL;
   p_Header_Adj_Assoc_tbl          OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ASSOC_TBL;
   p_old_Header_Adj_Assoc_tbl      OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_ADJ_ASSOC_TBL;
   p_Header_Scredit_tbl            OE_ORDER_PUB.Header_Scredit_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL;
   p_old_Header_Scredit_tbl        OE_ORDER_PUB.Header_Scredit_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_TBL;
   p_Header_Scredit_val_tbl        OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_VAL_TBL;
   p_old_Header_Scredit_val_tbl    OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_SCREDIT_VAL_TBL;
   p_line_tbl                      OE_ORDER_PUB.Line_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_TBL;
   p_old_line_tbl                  OE_ORDER_PUB.Line_Tbl_Type := OE_ORDER_PUB.G_MISS_LINE_TBL;
   p_line_val_tbl                  OE_ORDER_PUB.Line_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_VAL_TBL;
   p_old_line_val_tbl              OE_ORDER_PUB.Line_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_VAL_TBL;
   p_Line_Adj_tbl                  OE_ORDER_PUB.Line_Adj_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL;
   p_old_Line_Adj_tbl              OE_ORDER_PUB.Line_Adj_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_TBL;
   p_Line_Adj_val_tbl              OE_ORDER_PUB.Line_Adj_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_VAL_TBL;
   p_old_Line_Adj_val_tbl          OE_ORDER_PUB.Line_Adj_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_VAL_TBL;
   p_Line_price_Att_tbl            OE_ORDER_PUB.Line_Price_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_TBL;
   p_old_Line_Price_Att_tbl        OE_ORDER_PUB.Line_Price_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_PRICE_ATT_TBL;
   p_Line_Adj_Att_tbl              OE_ORDER_PUB.Line_Adj_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_ATT_TBL;
   p_old_Line_Adj_Att_tbl          OE_ORDER_PUB.Line_Adj_Att_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_ATT_TBL;
   p_Line_Adj_Assoc_tbl            OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_ASSOC_TBL;
   p_old_Line_Adj_Assoc_tbl        OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_ADJ_ASSOC_TBL;
   p_Line_Scredit_tbl              OE_ORDER_PUB.Line_Scredit_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL;
   p_old_Line_Scredit_tbl          OE_ORDER_PUB.Line_Scredit_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_TBL;
   p_Line_Scredit_val_tbl          OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_VAL_TBL;
   p_old_Line_Scredit_val_tbl      OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LINE_SCREDIT_VAL_TBL;
   p_Lot_Serial_tbl                OE_ORDER_PUB.Lot_Serial_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LOT_SERIAL_TBL;
   p_old_Lot_Serial_tbl            OE_ORDER_PUB.Lot_Serial_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LOT_SERIAL_TBL;
   p_Lot_Serial_val_tbl            OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LOT_SERIAL_VAL_TBL;
   p_old_Lot_Serial_val_tbl        OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_LOT_SERIAL_VAL_TBL;
   p_action_request_tbl            OE_ORDER_PUB.Request_Tbl_Type := OE_ORDER_PUB.G_MISS_REQUEST_TBL;
   x_header_val_rec                OE_ORDER_PUB.Header_Val_Rec_Type;
   x_Header_Adj_tbl                OE_ORDER_PUB.Header_Adj_Tbl_Type;
   x_Header_Adj_val_tbl            OE_ORDER_PUB.Header_Adj_Val_Tbl_Type;
   x_Header_price_Att_tbl          OE_ORDER_PUB.Header_Price_Att_Tbl_Type;
   x_Header_Adj_Att_tbl            OE_ORDER_PUB.Header_Adj_Att_Tbl_Type;
   x_Header_Adj_Assoc_tbl          OE_ORDER_PUB.Header_Adj_Assoc_Tbl_Type;
   x_Header_Scredit_tbl            OE_ORDER_PUB.Header_Scredit_Tbl_Type;
   x_Header_Scredit_val_tbl        OE_ORDER_PUB.Header_Scredit_Val_Tbl_Type;
   x_line_val_tbl                  OE_ORDER_PUB.Line_Val_Tbl_Type;
   x_Line_Adj_tbl                  OE_ORDER_PUB.Line_Adj_Tbl_Type;
   x_Line_Adj_val_tbl              OE_ORDER_PUB.Line_Adj_Val_Tbl_Type;
   x_Line_price_Att_tbl            OE_ORDER_PUB.Line_Price_Att_Tbl_Type;
   x_Line_Adj_Att_tbl              OE_ORDER_PUB.Line_Adj_Att_Tbl_Type;
   x_Line_Adj_Assoc_tbl            OE_ORDER_PUB.Line_Adj_Assoc_Tbl_Type;
   x_Line_Scredit_tbl              OE_ORDER_PUB.Line_Scredit_Tbl_Type;
   x_Line_Scredit_val_tbl          OE_ORDER_PUB.Line_Scredit_Val_Tbl_Type;
   x_Lot_Serial_tbl                OE_ORDER_PUB.Lot_Serial_Tbl_Type;
   x_Lot_Serial_val_tbl            OE_ORDER_PUB.Lot_Serial_Val_Tbl_Type;
   x_action_request_tbl            OE_ORDER_PUB.Request_Tbl_Type;

   l_x_header_payment_rec          OE_ORDER_PUB.Header_Payment_Rec_Type;
   l_x_header_payment_tbl          OE_ORDER_PUB.Header_Payment_Tbl_Type
                                      := OE_ORDER_PUB.G_MISS_HEADER_PAYMENT_TBL;

   x_header_payment_tbl            OE_ORDER_PUB.Header_Payment_Tbl_Type;
   x_Header_Payment_Val_Tbl_Type   OE_ORDER_PUB.Header_Payment_Val_Tbl_Type;
   x_Line_Payment_Tbl_Type         OE_ORDER_PUB.Line_Payment_Tbl_Type;
   x_Line_Payment_Val_Tbl_Type     OE_ORDER_PUB.Line_Payment_Val_Tbl_Type;

   X_DEBUG_FILE                    VARCHAR2 (100);
   l_line_tbl_index                NUMBER;
   l_msg_index_out                 NUMBER (10);
   ln_instr_id                     NUMBER;
   ln_cust_acct_id                 NUMBER;
   ln_party_id                     NUMBER;
   ln_org_id                       NUMBER := 204;
   ln_user_id                      NUMBER := 1013417;
   ln_r12_resp_id                  NUMBER:=21623;
   ln_r12_resp_appl_id             NUMBER := 660;
   lc_bt_cc_expiration             DATE;
   ln_inv_item_id                  NUMBER;
   lc_error_mesg                   VARCHAR2(30000);
   ln_ecomm_order_id               NUMBER;


  CURSOR get_instrid (c_order_id NUMBER)
  IS
  SELECT ins_u.instrument_id
    FROM iby_pmt_instr_uses_all ins_u
        ,iby_fndcpt_tx_extensions ins_ext
   WHERE ins_u.instrument_payment_use_id = ins_ext.instr_assignment_id
   AND ins_ext.order_id = to_char(c_order_id)
   ORDER BY ins_ext.creation_date desc;

  CURSOR get_customer_details
  IS
  SELECT hca.cust_account_id,
    hp.party_id
  FROM hz_cust_accounts hca,
    hz_parties hp
  WHERE hp.party_name         = p_party_name
  AND hp.party_id             = hca.party_id
  AND hp.status               = 'A'
  AND hca.status              = 'A';

  CURSOR get_inv_item_detail
  IS
  SELECT inventory_item_id
    FROM mtl_system_items_b
   WHERE segment1 = p_item_name
     AND organization_id  = 204;
BEGIN
--DBMS_output.put_line('Start :'||1);
   OPEN  get_customer_details;
   FETCH get_customer_details INTO ln_cust_acct_id,ln_party_id;
   CLOSE get_customer_details;

   IF ln_cust_acct_id IS NULL
   THEN
     x_ret_status := FND_API.G_RET_STS_ERROR;
     x_order_num := x_header_rec.order_number;
     lc_error_mesg := '*** BT-PLS: Invalid Party Details Passed';
     x_ret_message :=    lc_error_mesg;
     RETURN;
   END IF;
   --DBMS_output.put_line('Start :'||2);
   OPEN get_inv_item_detail;
   FETCH get_inv_item_detail INTO ln_inv_item_id;
   CLOSE get_inv_item_detail;

   IF ln_inv_item_id IS NULL
   THEN
     x_ret_status := FND_API.G_RET_STS_ERROR;
     x_order_num := x_header_rec.order_number;
     lc_error_mesg := '*** BT-PLS: Invalid Inventory Item Passed';
     x_ret_message :=    lc_error_mesg;
     RETURN;
   END IF;
   --DBMS_output.put_line('Start :'||3);
   lc_bt_cc_expiration     := LAST_DAY(TO_DATE(p_cc_expiration_date,'MM/YYYY'));
   DBMS_OUTPUT.enable (1000000);
   fnd_global.apps_initialize (ln_user_id, ln_r12_resp_id, ln_r12_resp_appl_id); -- pass in user_id, responsibility_id, and application_id
   MO_GLOBAL.INIT ('ONT');                                                       -- Required for R12
   mo_global.set_org_context (204, NULL, 'ONT');
   fnd_global.set_nls_context ('AMERICAN');
   MO_GLOBAL.SET_POLICY_CONTEXT ('S', 204);                                      -- Required for R12
   oe_msg_pub.initialize;
   oe_debug_pub.initialize;
   X_DEBUG_FILE := OE_DEBUG_PUB.Set_Debug_Mode ('FILE');
   oe_debug_pub.SetDebugLevel (5); -- Use 5 for the most debuging output, I warn you its a lot of data
   --DBMS_OUTPUT.put_line ('START OF NEW DEBUG');
   --This is to CREATE an order header and an order line
   --Create Header record
   --Initialize header record to missing
--DBMS_output.put_line('Start :'||4);
   l_header_rec := OE_ORDER_PUB.G_MISS_HEADER_REC;
   l_header_rec.TRANSACTIONAL_CURR_CODE := 'USD';
   l_header_rec.pricing_date := SYSDATE;
   l_header_rec.cust_po_number := lc_po_num;
   l_header_rec.sold_to_org_id := ln_cust_acct_id;--125737;
   l_header_rec.price_list_id := 1000;
   l_header_rec.ordered_date := SYSDATE;
   l_header_rec.shipping_method_code := 'DHL';
   l_header_rec.sold_from_org_id := ln_org_id;
   l_header_rec.ship_from_org_id := ln_org_id;
   --l_header_rec.booked_flag := 'Y';
   l_header_rec.salesrep_id := -3;
   l_header_rec.order_type_id := 1437;
   --DBMS_output.put_line('Start :'||5);
   --l_header_rec.flow_status_code := 'BOOKED';
   --l_header_rec.booked_date := SYSDATE;
   l_header_rec.operation := OE_GLOBALS.G_OPR_CREATE;
   l_header_rec.payment_type_code := p_pamt_method_type;--'CREDIT_CARD';--
   l_header_rec.credit_card_number := p_cc_num;--'4111111111111111';--
   l_header_rec.credit_card_code := p_cc_code;--'VISA';--
   l_header_rec.credit_card_holder_name := p_card_holder_name;--'All OracleApps';--
   --DBMS_output.put_line('lc_bt_cc_expiration :'||lc_bt_cc_expiration);
   l_header_rec.credit_card_expiration_date := lc_bt_cc_expiration;
   l_header_rec.credit_card_approval_code := p_bt_auth_code;
   l_header_rec.CREDIT_CARD_APPROVAL_DATE := SYSDATE;
   l_header_rec.payment_term_id := 5; --IMMEDIATE
   l_line_tbl_index := 1;
   --DBMS_output.put_line('Start :'||6);
   -- FIRST LINE RECORD
   -- Initialize record to missing
   l_line_tbl (l_line_tbl_index) := OE_ORDER_PUB.G_MISS_LINE_REC;
   -- Line attributes
   l_line_tbl (l_line_tbl_index).inventory_item_id := ln_inv_item_id;
   l_line_tbl (l_line_tbl_index).ordered_quantity := p_item_qty;
   l_line_tbl (l_line_tbl_index).ship_from_org_id := ln_org_id;
   --l_line_tbl (l_line_tbl_index).subinventory := 'FGI';
   l_line_tbl ( l_line_tbl_index ).calculate_price_flag  := 'Y';
   l_line_tbl (l_line_tbl_index).operation := OE_GLOBALS.G_OPR_CREATE;

  /* l_x_header_payment_rec.operation := OE_GLOBALS.G_OPR_CREATE;
   --l_x_header_payment_rec.header_index := 1;
   l_x_header_payment_rec.receipt_method_id := 1121;                                    --6875; --6755;
   l_x_header_payment_rec.payment_type_code := 'CREDIT_CARD';--p_pamt_method_type;--
   l_x_header_payment_rec.credit_card_number := '4111111111111111';--p_cc_num;--
   l_x_header_payment_rec.credit_card_code := 'VISA';--p_cc_code;--
   l_x_header_payment_rec.credit_card_holder_name := 'All OracleApps';--p_card_holder_name;--
   l_x_header_payment_rec.credit_card_expiration_date := SYSDATE + 100;
   l_x_header_payment_rec.payment_level_code := 'ORDER';
   --l_x_header_payment_rec.prepaid_amount := 100;
   l_x_header_payment_tbl (1) := l_x_header_payment_rec;*/

  l_action_request_tbl(1).request_type := oe_globals.g_book_order;
  l_action_request_tbl(1).entity_code := oe_globals.g_entity_header;
  --DBMS_output.put_line('Start :'||7);
   -- CALL TO PROCESS ORDER Check the return status and then commit.
   OE_ORDER_PUB.process_order (p_api_version_number       => 1.0,
                               p_init_msg_list            => fnd_api.g_false,
                               p_return_values            => fnd_api.g_false,
                               p_action_commit            => fnd_api.g_false,
                               x_return_status            => l_return_status,
                               x_msg_count                => l_msg_count,
                               x_msg_data                 => l_msg_data,
                               p_header_rec               => l_header_rec,
                               p_line_tbl                 => l_line_tbl,
                               p_action_request_tbl       => l_action_request_tbl,
                               p_Header_Payment_tbl       => l_x_header_payment_tbl-- OUT PARAMETERS
                               ,
                               x_header_rec               => x_header_rec,
                               x_header_val_rec           => x_header_val_rec,
                               x_Header_Adj_tbl           => x_Header_Adj_tbl,
                               x_Header_Adj_val_tbl       => x_Header_Adj_val_tbl,
                               x_Header_price_Att_tbl     => x_Header_price_Att_tbl,
                               x_Header_Adj_Att_tbl       => x_Header_Adj_Att_tbl,
                               x_Header_Adj_Assoc_tbl     => x_Header_Adj_Assoc_tbl,
                               x_Header_Scredit_tbl       => x_Header_Scredit_tbl,
                               x_Header_Scredit_val_tbl   => x_Header_Scredit_val_tbl,
                               x_Header_Payment_tbl       => x_header_payment_tbl,
                               x_Header_Payment_val_tbl   => x_Header_Payment_Val_Tbl_Type,
                               x_line_tbl                 => p_line_tbl,
                               x_line_val_tbl             => x_line_val_tbl,
                               x_Line_Adj_tbl             => x_Line_Adj_tbl,
                               x_Line_Adj_val_tbl         => x_Line_Adj_val_tbl,
                               x_Line_price_Att_tbl       => x_Line_price_Att_tbl,
                               x_Line_Adj_Att_tbl         => x_Line_Adj_Att_tbl,
                               x_Line_Adj_Assoc_tbl       => x_Line_Adj_Assoc_tbl,
                               x_Line_Scredit_tbl         => x_Line_Scredit_tbl,
                               x_Line_Scredit_val_tbl     => x_Line_Scredit_val_tbl,
                               x_Line_Payment_tbl         => x_Line_Payment_Tbl_Type,
                               x_Line_Payment_val_tbl     => x_Line_Payment_Val_Tbl_Type,
                               x_Lot_Serial_tbl           => x_Lot_Serial_tbl,
                               x_Lot_Serial_val_tbl       => x_Lot_Serial_val_tbl,
                               x_action_request_tbl       => x_action_request_tbl);
   DBMS_OUTPUT.put_line ('OM Debug file: ' || oe_debug_pub.G_DIR || '/' || oe_debug_pub.G_FILE);
   DBMS_OUTPUT.put_line ('Header_ID : ' || x_header_rec.header_id);
   DBMS_OUTPUT.put_line ('SO = : ' || x_header_rec.order_number);

   -- Retrieve messages
   FOR i IN 1 .. l_msg_count
   LOOP
      Oe_Msg_Pub.get (p_msg_index       => i,
                      p_encoded         => Fnd_Api.G_FALSE,
                      p_data            => l_msg_data,
                      p_msg_index_out   => l_msg_index_out);
      DBMS_OUTPUT.PUT_LINE ('message is: ' || l_msg_data);
      lc_error_mesg := lc_error_mesg||'::'||l_msg_data;
      DBMS_OUTPUT.PUT_LINE ('message index is: ' || l_msg_index_out);
   END LOOP;
  -- DBMS_OUTPUT.put_line ('8');
   -- Check the return status
   IF l_return_status = FND_API.G_RET_STS_SUCCESS
   THEN
    --x_order_num := x_header_rec.order_number;
    OPEN get_instrid (x_header_rec.header_id);
    FETCH get_instrid INTO ln_instr_id;
    CLOSE get_instrid;

    IF ln_instr_id IS NOT NULL
    THEN
      DBMS_OUTPUT.put_line ('Process Order Sucess');
      x_ret_status := xxbt_payment_method_pkg.gc_success;
      x_order_num := x_header_rec.order_number;
      x_instrid   := ln_instr_id;


      ln_ecomm_order_id := xxbt_cc_details_s.NEXTVAL;
      xxbt_payment_method_pkg.ecomm_post_order_synch (
          p_ecomm_order_id   => ln_ecomm_order_id,
          p_ecomm_customer_id  => 1,
          p_operation_type     => p_pmt_method_opn_type,
          p_order_id           => x_header_rec.header_id,
          p_quote_id           => NULL,
          p_party_id           => ln_party_id,
          p_cust_account_id    => ln_cust_acct_id,
          p_party_site_id      => NULL,
          p_location_id        => NULL,
          p_org_id            => ln_org_id,
          p_r12_user_id       => ln_user_id,
          p_r12_resp_id       => ln_r12_resp_id,
          p_r12_resp_appl_id  => ln_r12_resp_appl_id,
          p_iby_instrument_id => ln_instr_id,
          p_paypal_email      => NULL,
          p_cc_expiration_date => p_cc_expiration_date,
          p_bt_customer_id     => p_bt_customer_id,
          p_bt_billing_address_id  => NULL,
          p_bt_payment_method_token  => p_bt_payment_method_token,
          p_bt_transaction_id         => p_bt_transaction_id,
          p_bt_auth_code              => p_bt_auth_code,
          p_kount_risk_id             => NULL,
          p_kount_risk_decision      => NULL,
          p_bt_device_data            => NULL,
          p_bt_3d_secure              => NULL,
          p_bt_payment_method_nonce   => NULL,
          x_ret_status               => x_ret_status,
          x_ret_message              => lc_error_mesg,
          x_ret_cc_det_id            => x_ret_cc_det_id,
          x_ret_pymt_tran_id         => x_ret_pymt_tran_id);
    ELSE
      x_ret_status := xxbt_payment_method_pkg.gc_error;
      x_order_num := x_header_rec.order_number;
      lc_error_mesg := '*** BT-PLS: Error Deriving Instrument ID';
    END IF;
   ELSE
      DBMS_OUTPUT.put_line ('Failed');
      x_ret_status := xxbt_payment_method_pkg.gc_error;
   END IF;
   x_ret_message :=    lc_error_mesg;
EXCEPTION
   WHEN OTHERS
   THEN
      x_ret_status := xxbt_payment_method_pkg.gc_error;
      x_ret_message := 'Unexpected Error : '||SQLERRM||'::'||dbms_utility.format_error_backtrace;
      DBMS_OUTPUT.PUT_LINE ('Unexpected Error : ' || SQLERRM||'::'||dbms_utility.format_error_backtrace);
END process_order;
END xxbt_ecomm_test_pkg;
/


