
-- This is for calling the Internal Procedure to get the TCA_INFO. You need to pass the TRXN_ID for the.
-- This is the call from Java Concurrent Program. this is for Internal Testing only.


DECLARE
  lx_xxbt_cc_id          NUMBER;
  lx_ret_status          VARCHAR2(20);
  lx_ret_message         VARCHAR2(2000);
  lx_output_json         VARCHAR2(4000);
  lx_payment_Method_Type VARCHAR2(100);
  lx_name_on_Card        VARCHAR2(500);
  lx_nonce               VARCHAR2(1000);
  lx_trxn_id             NUMBER;
BEGIN
  xxbt_payment_method_pkg.get_paypal_tca_info (p_trxn_id => 1014, 
                                                x_output_json => lx_output_json, 
                                                x_payment_Method_Type => lx_payment_Method_Type, 
                                                x_name_on_Card => lx_name_on_Card, 
                                                x_nonce => lx_nonce, 
                                                x_trxn_id => lx_trxn_id);
                                                
  dbms_output.put_line('lx_trxn_id :'||lx_trxn_id);
  dbms_output.put_line('lx_payment_Method_Type :'||lx_payment_Method_Type);
  dbms_output.put_line('lx_name_on_Card :'||lx_name_on_Card);
  dbms_output.put_line('lx_nonce :'||lx_nonce);
  dbms_output.put_line('lx_output_json :'||lx_output_json);
END;
