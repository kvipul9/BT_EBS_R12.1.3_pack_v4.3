DECLARE
lx_xxbt_cc_id NUMBER;
lx_ret_status varchar2(20);
lx_ret_message Varchar2(2000);

begin

xxbt_payment_method_pkg. get_bt_paypal_paym_request (
      p_nonce  => '4f75c36a-d418-4bf2-933c-b9a908cc013e',
      p_payPal_Email  => 'ebs_buyer_6@ebs.com',
      p_first_Name  =>'Hari',
      p_last_Name  => 'Kav',
      p_phone_Number  => NULL,
      p_payer_Id  =>'ZZ5MLJAH95ZZZz',
      p_hz_Bill_Party_Id  => 415679,
      p_hz_Bill_cust_AcctID  => 129734,
      p_hz_Bill_Party_Type  => 'ORGANIZATION',
      p_hz_Bill_Party_SiteID  => 240632,
      p_company_name  => NULL,
      p_bill_Street_Address  => NULL,
      p_bill_City  => NULL,
      p_bill_State  => NULL,
      p_bill_Zip  => NULL,
      p_bill_Country  => NULL,
      p_hz_Ship_PartyID  => NULL,
      p_hz_Ship_Party_SiteID  => NULL,
      p_hz_Ship_cust_AcctID  => NULL,
      p_ship_Recipient_Name  => NULL,
      p_ship_Street_Address  => 'SHIP Street 1,',
      p_ship_City  => 'Lansdale',
      p_ship_State  => 'PA',
      p_ship_Zip  => '19334',
      p_ship_Country  => 'US',
      p_orgID  => 204,
      p_currency_code => 'USD',
      p_source_RefID  => NULL,
      p_Source_RefType  =>NULL,
      p_pay_Method_Type  =>'PAYPAL',
      p_vaulted  => 'Y',
      p_single_Use_Flag  => 'N',
      p_paypal_AcctName  => 'Hari K',
      x_xxbt_cc_id  => lx_xxbt_cc_id,
      x_ret_status => lx_ret_status,
      x_ret_message => lx_ret_message);
      
 dbms_output.put_line('lx_ret_status :'||lx_ret_status);   
 dbms_output.put_line('x_ret_message :'||lx_ret_message);    
 
 END;