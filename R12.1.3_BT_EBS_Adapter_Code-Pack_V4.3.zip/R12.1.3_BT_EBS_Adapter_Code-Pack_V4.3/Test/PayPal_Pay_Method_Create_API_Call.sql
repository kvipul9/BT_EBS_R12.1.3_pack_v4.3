-- Paypal Demo 6 CUST
DECLARE
x_trxn_id NUMBER;
x_xxbt_cc_id NUMBER;
x_request_id NUMBER;
x_ret_status VARCHAR2(32000);
x_ret_message VARCHAR2(32000);

begin

xxbt_payment_method_pkg. get_bt_paypal_paym_request (
      p_nonce  => 'ff0e7d85-8d2d-410b-8d9b-a5edb91986d4',
      p_payPal_Email  => 'ebs_buyer_61@ebs.com',
      p_first_Name  =>'Paypal 6',
      p_last_Name  => 'Demo',
      p_phone_Number  => '123-456-6611',
      p_payer_Id  =>'EBQ94E2YPZHZ8',
      
      p_hz_Bill_Party_Id  => 416697,
      p_hz_Bill_cust_AcctID  => 130744,
      p_hz_Bill_Party_Type  => 'PERSON',
      p_hz_Bill_Party_SiteID  => 241642,
      p_company_name  => NULL,
      p_bill_Street_Address  => '1125 Paypal Way',
      p_bill_City  => 'Irving',
      p_bill_State  => 'TX',
      p_bill_Zip  => '75038',
      p_bill_Country  => 'USA',
      p_hz_Ship_PartyID  => NULL,
      p_hz_Ship_Party_SiteID  => NULL,
      p_hz_Ship_cust_AcctID  => NULL,
      p_ship_Recipient_Name  => NULL,
      p_ship_Street_Address  => 'SHIP Street 2,',
      p_ship_City  => 'Lansdale',
      p_ship_State  => 'PA',
      p_ship_Zip  => '19334',
      p_ship_Country  => 'US',
      p_orgID  => 204,
      p_currency_code => 'USD',
      p_source_RefID  => 'PAYPAL API',
      p_Source_RefType  => 11226666,
      p_pay_Method_Type  => 'PAYPAL',
      p_vaulted  => 'Y',
      p_single_Use_Flag  => 'N',
      p_paypal_acctname=>'Paypal Demo 11226644',
    x_trxn_id=>x_trxn_id,
    x_xxbt_cc_id=>x_xxbt_cc_id,
    x_request_id=>x_request_id,
    x_ret_status=>x_ret_status,
    x_ret_message=>x_ret_message);

  sys.dbms_output.put_line('X_TRXN_ID = '||TO_CHAR(X_TRXN_ID));
  sys.dbms_output.put_line('X_XXBT_CC_ID = '||TO_CHAR(X_XXBT_CC_ID));
  sys.dbms_output.put_line('X_REQUEST_ID = '||TO_CHAR(X_REQUEST_ID));
  sys.dbms_output.put_line('X_RET_STATUS = '||SUBSTR(X_RET_STATUS,1,255));
  sys.dbms_output.put_line('X_RET_MESSAGE = '||SUBSTR(X_RET_MESSAGE,1,255));

EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line(SubStr('Error '||TO_CHAR(SQLCODE)||': '||SQLERRM, 1, 255));
    dbms_output.put_line(dbms_utility.format_error_backtrace);
  RAISE;
END;







