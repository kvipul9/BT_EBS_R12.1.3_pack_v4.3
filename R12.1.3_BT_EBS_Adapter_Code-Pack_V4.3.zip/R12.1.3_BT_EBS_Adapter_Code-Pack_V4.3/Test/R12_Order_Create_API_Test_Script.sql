DECLARE

lx_ret_status VARCHAR2(10);
lx_ret_MESSAGE VARCHAR2(30000);
lx_order_num VARCHAR2(250);
lx_instrid NUMBER;
lx_ret_cc_det_id NUMBER;
lx_ret_pymt_tran_id NUMBER;

begin

xxbt_ecomm_test_pkg.process_order(p_party_name => 'VKCORP5'
                       ,p_item_name => '0001-0120H'
                       ,p_item_qty => 2
                       ,p_pamt_method_type => 'CREDIT_CARD'
                       ,p_cc_num => '3559024759181117'
                       ,p_cc_expiration_date => '10/2018'
                       ,p_cc_code => 'DISCOVER'
                       ,p_card_holder_name => 'Test Veekay Disco1'
                       ,p_po_number => NULL
                       ,p_pmt_method_opn_type => 'I'
                       ,p_bt_auth_code => '82NF47'
                       ,p_bt_transaction_id => NULL
                       ,p_bt_customer_id => NULL
                       ,p_bt_payment_method_token => NULL
                       ,x_ret_status => lx_ret_status
                       ,x_ret_message => lx_ret_message
                       ,x_order_num => lx_order_num
                       ,x_instrid => lx_instrid
                       ,x_ret_cc_det_id => lx_ret_cc_det_id
                       ,x_ret_pymt_tran_id => lx_ret_pymt_tran_id
                       );
                       
DBMS_OUTPUT.PUT_LINE('lx_ret_status :'||lx_ret_status);                       
DBMS_OUTPUT.PUT_LINE('lx_ret_message :'||lx_ret_message);
DBMS_OUTPUT.PUT_LINE('lx_order_num :'||lx_order_num);
DBMS_OUTPUT.PUT_LINE('lx_instrid :'||lx_instrid);

EXCEPTION
WHEN OTHERS
THEN

DBMS_OUTPUT.PUT_LINE(SQLERRM);

END;
